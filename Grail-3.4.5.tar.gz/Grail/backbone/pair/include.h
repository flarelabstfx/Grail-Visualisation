//#This comes from 3.1.4-new
//	This code copyright (c) by the Grail project.
//	No commercial use permitted without written consent.
//	July 1995

#ifndef PAIR_INCLUDE_H
#define PAIR_INCLUDE_H


namespace grail
{
#include	"pair.h"
#include	"eq.src"
#include	"istream.src"
#include	"ostream.src"
#include	"lt.src"

}


#endif
