//#This comes from 3.1.4-new
#ifndef STATE_ENUM
	#define STATE_ENUM
// specification for state role in an instruction
enum state_type { SOURCE, SINK, EITHER };
#endif
