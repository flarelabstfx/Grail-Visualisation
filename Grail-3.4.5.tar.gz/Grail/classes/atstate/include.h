//#This comes from 3.1.4-new

#ifndef ATSTATE_INCLUDE_H
#define ATSTATE_INCLUDE_H

/* Added namespace grail, Brandon Stewart, July 2015 */
namespace grail
{

#include "atstate.h"
#include "atstate.src"

}

#endif
