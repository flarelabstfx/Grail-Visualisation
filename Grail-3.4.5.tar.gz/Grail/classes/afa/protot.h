//#This comes from 3.1.4-new



//this file include the prototypes for the procedures that manage 
//integers and integer arrays

int  find_min_log (int);

int  compare_int(unsigned, unsigned);

int  find_max(int*, int);

void sort_int_array(int*, int);

