//#This comes from 3.1.4-new

#ifndef AFA_DNF_INCLUDE_H
#define AFA_DNF_INCLUDE_H

#include <ctype.h>
#include <stdio.h>
#include <iostream>

#include <cmath> //by SH 05/26/2005

namespace grail
{

#include "../manage_bitvec.src"

#include        "term.h"
#include        "function.h"
#include        "termsim.src"
#include        "function.src"
#include        "functios.src"

#include        "substitute.src"

}

#endif
