int debug = 0;
char* nfatodfca_name = ""; //for special debug
#include "../char/include.h"
#include "../char/lexical.h"

